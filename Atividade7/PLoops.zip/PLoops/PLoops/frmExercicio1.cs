﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnSpace_Click(object sender, EventArgs e)
        {
            if(ValidarFrase())
            {
                int n = 0, cont = 0;

                while (cont < rchTexto.Text.Length)
                {
                    if (char.IsWhiteSpace(rchTexto.Text, cont))
                    {
                        n++;
                    }
                    cont++;

                }
                MessageBox.Show("Quantidade de espaços = " + n.ToString());
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            if(ValidarFrase())
            {
                int n = 0;

                foreach (char x in rchTexto.Text.ToUpper())
                    if (x == 'R')
                        n++;

                MessageBox.Show("Quantidade de R = " + n.ToString());
            }
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            if(ValidarFrase())
            {
                int n = 0;

                for (int cont = 0; cont < rchTexto.Text.Length; cont++)
                {
                    if (char.IsWhiteSpace(rchTexto.Text[cont]))
                        cont++;
                    else if (cont < rchTexto.Text.Length - 1 && rchTexto.Text[cont] == rchTexto.Text[cont + 1])
                        n++;
                }
                MessageBox.Show("Quantidade de par(es) de letra = " + n.ToString());
            }
                
        }

        private bool ValidarFrase()
        {
            string frase = rchTexto.Text;
            if (frase.Length > 100)
            {
                MessageBox.Show("A frase deve ter no máximo 100 caracteres.");
                return false;
            }
            return true;
        }
    }
}
