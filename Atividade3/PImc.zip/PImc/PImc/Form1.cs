﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(mskbxPeso.Text,out peso))
            {
                MessageBox.Show("Digite um valor valido para Peso!");
                e.Cancel = true;    
            }
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Digite um valor valido para Altura!");
                e.Cancel = true;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Text = string.Empty;
            txtImc.Text = ""; 
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ( peso<=0)
            {
                MessageBox.Show("Digite um valor maior que zero para Peso");
                mskbxPeso.Focus();
            }
            else if (altura <= 0)
            {
                MessageBox.Show("Digite um valor maior que zero para Altura");
                mskbxAltura.Focus();
            }
            else 
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                txtImc.Text = Convert.ToString(imc);

                if (imc < 18.5)
                {
                    MessageBox.Show("Classificação Magreza (Obesidade Grau 0)");
                }
                else if (imc < 24.9)
                {
                    MessageBox.Show("Classificação Normal (Obesidade Grau 0)");
                }
                else if (imc < 29.9)
                {
                    MessageBox.Show("Classificação Sobrepeso (Obesidade Grau I)");
                }
                else if (imc < 39.9)
                {
                    MessageBox.Show("Classificação Obesidade (Obesidade Grau II)");
                }
                else
                {
                    MessageBox.Show("Classificação Obesidade Grave (Obesidade Grau III)");
                }

            }

        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
