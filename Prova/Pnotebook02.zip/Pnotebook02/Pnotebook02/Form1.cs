﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        double[,] precoNotebook = new double[2,3];
        string[] strAux = new string[2];
        double auxiliar=0, somatorioIndividual=0, mediaIndividual=0,mediaGeral=0;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxPesquisa.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            for(int x=0;x<1;x++) 
            {
                for (int i =0;i< precoNotebook.GetLength(0); i++)
                {
                    strAux[i] += $"Notebook {i + 1}: ";
                    for(int j=0;j< precoNotebook.GetLength(1); j++)
                    {
                        //string stringINPUT = Interaction.InputBox($"Digite o preço do notebook {i + 1} na loja {j + 1} ");
                       // if (!double.TryParse(stringINPUT, out auxiliar))
                       if (!double.TryParse(Interaction.InputBox($"Digite o preço do notebook {i + 1} na loja {j + 1} "), out auxiliar)||auxiliar<0||auxiliar==null)
                        
                        {
                            MessageBox.Show("Digite um valor valido");
                            j--;
                        }
                        else
                        {
                            precoNotebook[i,j] = auxiliar;
                            strAux[i] += $"Loja {j + 1}: R$ {precoNotebook[i, j].ToString("N2")} ";
                            somatorioIndividual += auxiliar;
                            if (j == 2)
                            {
                                mediaIndividual = somatorioIndividual / 3.0;
                                strAux[i] += $" Média R$ {mediaIndividual.ToString("N2")}";
                                mediaGeral += mediaIndividual;
                            }

                        }

                        

                    }
                    mediaIndividual = 0;
                    somatorioIndividual= 0;
                }
                mediaGeral = mediaGeral / 2;
                lstboxPesquisa.Items.AddRange(strAux);
                lstboxPesquisa.Items.Add("------------------------------------------------------");
                lstboxPesquisa.Items.Add($"Media Geral Notebooks: {mediaGeral.ToString("N2")}");

            }
            somatorioIndividual = 0;
            mediaIndividual = 0;
            mediaGeral = 0;
        }
    }
}
