﻿namespace PTesteMetodos.Forms
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnComparar = new System.Windows.Forms.Button();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.btnInserirMeio = new System.Windows.Forms.Button();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnInserirAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnComparar
            // 
            this.btnComparar.FlatAppearance.BorderSize = 0;
            this.btnComparar.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnComparar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btnComparar.Location = new System.Drawing.Point(54, 214);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(144, 57);
            this.btnComparar.TabIndex = 4;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = false;
            this.btnComparar.Click += new System.EventHandler(this.btnCompararPalavra_Click);
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblPalavra2.ForeColor = System.Drawing.Color.DarkCyan;
            this.lblPalavra2.Location = new System.Drawing.Point(67, 144);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(79, 19);
            this.lblPalavra2.TabIndex = 0;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblPalavra1.ForeColor = System.Drawing.Color.DarkCyan;
            this.lblPalavra1.Location = new System.Drawing.Point(67, 79);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(79, 19);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(169, 76);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(0);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(462, 26);
            this.txtPalavra1.TabIndex = 1;
            // 
            // btnInserirMeio
            // 
            this.btnInserirMeio.FlatAppearance.BorderSize = 0;
            this.btnInserirMeio.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnInserirMeio.ForeColor = System.Drawing.Color.DarkCyan;
            this.btnInserirMeio.Location = new System.Drawing.Point(280, 214);
            this.btnInserirMeio.Name = "btnInserirMeio";
            this.btnInserirMeio.Size = new System.Drawing.Size(144, 57);
            this.btnInserirMeio.TabIndex = 3;
            this.btnInserirMeio.Text = " Inserir \r\nno meio";
            this.btnInserirMeio.UseVisualStyleBackColor = false;
            this.btnInserirMeio.Click += new System.EventHandler(this.btnInserirMeio_Click);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(169, 140);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(0);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(462, 26);
            this.txtPalavra2.TabIndex = 2;
            // 
            // btnInserirAsteriscos
            // 
            this.btnInserirAsteriscos.FlatAppearance.BorderSize = 0;
            this.btnInserirAsteriscos.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnInserirAsteriscos.ForeColor = System.Drawing.Color.DarkCyan;
            this.btnInserirAsteriscos.Location = new System.Drawing.Point(486, 214);
            this.btnInserirAsteriscos.Name = "btnInserirAsteriscos";
            this.btnInserirAsteriscos.Size = new System.Drawing.Size(144, 57);
            this.btnInserirAsteriscos.TabIndex = 5;
            this.btnInserirAsteriscos.Text = "Inserir asteriscos";
            this.btnInserirAsteriscos.UseVisualStyleBackColor = false;
            this.btnInserirAsteriscos.Click += new System.EventHandler(this.btnInserirAsteriscos_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.btnInserirAsteriscos);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.btnInserirMeio);
            this.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExercicio2";
            this.Text = "Exercício 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.Button btnInserirMeio;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnInserirAsteriscos;
    }
}