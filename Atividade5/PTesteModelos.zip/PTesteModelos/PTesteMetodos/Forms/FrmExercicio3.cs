﻿using System;
using System.Windows.Forms;

namespace PTesteMetodos.Forms
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (txtPalavra1.Text.Length > 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
            }
        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            char[] caracteresInvertidos = txtPalavra1.Text.ToCharArray();
            
            Array.Reverse(caracteresInvertidos);

            String palavra = new String(caracteresInvertidos);

            MessageBox.Show(palavra);
        }
    }
}
