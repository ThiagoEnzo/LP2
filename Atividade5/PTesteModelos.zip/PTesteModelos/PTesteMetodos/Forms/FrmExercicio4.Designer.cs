﻿namespace PTesteMetodos.Forms
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEncontrarEspaco = new System.Windows.Forms.Button();
            this.btnContarNumericos = new System.Windows.Forms.Button();
            this.btnContarAlfabeticos = new System.Windows.Forms.Button();
            this.rhtxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEncontrarEspaco
            // 
            this.btnEncontrarEspaco.FlatAppearance.BorderSize = 0;
            this.btnEncontrarEspaco.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnEncontrarEspaco.Location = new System.Drawing.Point(265, 229);
            this.btnEncontrarEspaco.Name = "btnEncontrarEspaco";
            this.btnEncontrarEspaco.Size = new System.Drawing.Size(138, 74);
            this.btnEncontrarEspaco.TabIndex = 24;
            this.btnEncontrarEspaco.Text = "Encontrar espaço";
            this.btnEncontrarEspaco.UseVisualStyleBackColor = false;
            this.btnEncontrarEspaco.Click += new System.EventHandler(this.btnEncontrarEspaco_Click);
            // 
            // btnContarNumericos
            // 
            this.btnContarNumericos.FlatAppearance.BorderSize = 0;
            this.btnContarNumericos.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnContarNumericos.Location = new System.Drawing.Point(33, 229);
            this.btnContarNumericos.Name = "btnContarNumericos";
            this.btnContarNumericos.Size = new System.Drawing.Size(138, 74);
            this.btnContarNumericos.TabIndex = 23;
            this.btnContarNumericos.Text = "Contar numéricos";
            this.btnContarNumericos.UseVisualStyleBackColor = false;
            this.btnContarNumericos.Click += new System.EventHandler(this.btnContarNumericos_Click);
            // 
            // btnContarAlfabeticos
            // 
            this.btnContarAlfabeticos.FlatAppearance.BorderSize = 0;
            this.btnContarAlfabeticos.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.btnContarAlfabeticos.Location = new System.Drawing.Point(498, 229);
            this.btnContarAlfabeticos.Name = "btnContarAlfabeticos";
            this.btnContarAlfabeticos.Size = new System.Drawing.Size(138, 74);
            this.btnContarAlfabeticos.TabIndex = 33;
            this.btnContarAlfabeticos.Text = "Contar alfabéticos";
            this.btnContarAlfabeticos.UseVisualStyleBackColor = false;
            this.btnContarAlfabeticos.Click += new System.EventHandler(this.btnContarAlfabeticos_Click);
            // 
            // rhtxtFrase
            // 
            this.rhtxtFrase.BackColor = System.Drawing.Color.Honeydew;
            this.rhtxtFrase.Location = new System.Drawing.Point(18, 49);
            this.rhtxtFrase.Name = "rhtxtFrase";
            this.rhtxtFrase.Size = new System.Drawing.Size(640, 146);
            this.rhtxtFrase.TabIndex = 0;
            this.rhtxtFrase.Text = "";
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(18, 27);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(52, 19);
            this.lblFrase.TabIndex = 27;
            this.lblFrase.Text = "Frase";
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.rhtxtFrase);
            this.Controls.Add(this.btnContarAlfabeticos);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnEncontrarEspaco);
            this.Controls.Add(this.btnContarNumericos);
            this.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.ForeColor = System.Drawing.Color.ForestGreen;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEncontrarEspaco;
        private System.Windows.Forms.Button btnContarNumericos;
        private System.Windows.Forms.Button btnContarAlfabeticos;
        private System.Windows.Forms.RichTextBox rhtxtFrase;
        private System.Windows.Forms.Label lblFrase;
    }
}