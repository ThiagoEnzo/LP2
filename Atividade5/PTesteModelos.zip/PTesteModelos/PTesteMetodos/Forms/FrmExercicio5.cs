﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace PTesteMetodos.Forms
{
    public partial class FrmExercicio5 : Form
    {
        int min, max;

        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void txtMin_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtMin.Text, out min))
            {
                errorProvider.SetError(txtMin, "Deve ser um inteiro!");
            }
            else if (min <= 0)
            {
                errorProvider.SetError(txtMin, "Deve ser maior que zero!");
            }
            else
            {
                errorProvider.SetError(txtMin, "");
            }
        }

        private void txtMax_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtMax.Text, out max))
            {
                errorProvider.SetError(txtMax, "Deve ser um inteiro!");
            }
            else if (max <= 0)
            {
                errorProvider.SetError(txtMax, "Deve ser maior que zero!");
            }
            else
            {
                errorProvider.SetError(txtMax, "");
            }
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtMin.Text, out min))
            {
                errorProvider.SetError(txtMin, "Deve ser um inteiro!");
                return;
            }
            else if (min <= 0)
            {
                errorProvider.SetError(txtMin, "Deve ser maior que zero!");
                return;
            }
            else
            {
                errorProvider.SetError(txtMin, "");
            }

            if (!int.TryParse(txtMax.Text, out max))
            {
                errorProvider.SetError(txtMax, "Deve ser um inteiro!");
                return;
            }
            else if (max <= 0)
            {
                errorProvider.SetError(txtMax, "Deve ser maior que zero!");
                return;
            }
            else
            {
                errorProvider.SetError(txtMax, "");
            }

            if (min >= max)
            {
                errorProvider.SetError(txtMin, "Mínimo deve ser menor do que o máximo!");
                errorProvider.SetError(txtMax, "Mínimo deve ser menor do que o máximo!");
                return;
            }
            else
            {
                errorProvider.SetError(txtMin, "");
                errorProvider.SetError(txtMax, "");
            }

            Random random = new Random();

            int sorteado = random.Next(min, max);

            MessageBox.Show(sorteado.ToString());
        }
    }
}
