﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            ListBox.Items.Clear();

            string[] nomes = new string[10];

            for (int cont = 0; cont < 10; cont++)
            {
                nomes[cont] = Interaction.InputBox($"insira o nome da {cont + 1}° pessoa", "Entrada de dados");
                nomes[cont] = $"O nome: {nomes[cont]} tem {nomes[cont].Replace(" ", "").Length.ToString()} caracteres";
            }

            ListBox.Items.AddRange(nomes);
        }
    }
}
