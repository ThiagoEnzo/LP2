﻿namespace PTesteMatrizes
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExercicio4 = new System.Windows.Forms.Button();
            this.BtnExercicio1 = new System.Windows.Forms.Button();
            this.BtnExercicio2 = new System.Windows.Forms.Button();
            this.BtnExercicio5 = new System.Windows.Forms.Button();
            this.BtnExercicio3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnExercicio4
            // 
            this.BtnExercicio4.Location = new System.Drawing.Point(422, 223);
            this.BtnExercicio4.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExercicio4.Name = "BtnExercicio4";
            this.BtnExercicio4.Size = new System.Drawing.Size(126, 50);
            this.BtnExercicio4.TabIndex = 0;
            this.BtnExercicio4.Text = "Exercício 4";
            this.BtnExercicio4.UseVisualStyleBackColor = true;
            this.BtnExercicio4.Click += new System.EventHandler(this.BtnExercicio4_Click);
            // 
            // BtnExercicio1
            // 
            this.BtnExercicio1.Location = new System.Drawing.Point(27, 222);
            this.BtnExercicio1.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExercicio1.Name = "BtnExercicio1";
            this.BtnExercicio1.Size = new System.Drawing.Size(126, 52);
            this.BtnExercicio1.TabIndex = 1;
            this.BtnExercicio1.Text = "Exercicio 1";
            this.BtnExercicio1.UseVisualStyleBackColor = true;
            this.BtnExercicio1.Click += new System.EventHandler(this.BtnExercicio1_Click);
            // 
            // BtnExercicio2
            // 
            this.BtnExercicio2.Location = new System.Drawing.Point(162, 222);
            this.BtnExercicio2.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExercicio2.Name = "BtnExercicio2";
            this.BtnExercicio2.Size = new System.Drawing.Size(117, 52);
            this.BtnExercicio2.TabIndex = 2;
            this.BtnExercicio2.Text = "Exercício 2";
            this.BtnExercicio2.UseVisualStyleBackColor = true;
            this.BtnExercicio2.Click += new System.EventHandler(this.BtnExercicio2_Click);
            // 
            // BtnExercicio5
            // 
            this.BtnExercicio5.Location = new System.Drawing.Point(557, 223);
            this.BtnExercicio5.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExercicio5.Name = "BtnExercicio5";
            this.BtnExercicio5.Size = new System.Drawing.Size(117, 50);
            this.BtnExercicio5.TabIndex = 3;
            this.BtnExercicio5.Text = "Exercício 5";
            this.BtnExercicio5.UseVisualStyleBackColor = true;
            this.BtnExercicio5.Click += new System.EventHandler(this.BtnExercicio5_Click);
            // 
            // BtnExercicio3
            // 
            this.BtnExercicio3.Location = new System.Drawing.Point(288, 222);
            this.BtnExercicio3.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExercicio3.Name = "BtnExercicio3";
            this.BtnExercicio3.Size = new System.Drawing.Size(125, 52);
            this.BtnExercicio3.TabIndex = 4;
            this.BtnExercicio3.Text = "Exercício 3";
            this.BtnExercicio3.UseVisualStyleBackColor = true;
            this.BtnExercicio3.Click += new System.EventHandler(this.BtnExercicio3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(112, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(476, 48);
            this.label1.TabIndex = 5;
            this.label1.Text = "Exercícios Array / Matriz";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 336);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnExercicio3);
            this.Controls.Add(this.BtnExercicio5);
            this.Controls.Add(this.BtnExercicio2);
            this.Controls.Add(this.BtnExercicio1);
            this.Controls.Add(this.BtnExercicio4);
            this.ForeColor = System.Drawing.Color.Red;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmPrincipal";
            this.Text = "PMatrizes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnExercicio4;
        private System.Windows.Forms.Button BtnExercicio1;
        private System.Windows.Forms.Button BtnExercicio2;
        private System.Windows.Forms.Button BtnExercicio5;
        private System.Windows.Forms.Button BtnExercicio3;
        private System.Windows.Forms.Label label1;
    }
}

