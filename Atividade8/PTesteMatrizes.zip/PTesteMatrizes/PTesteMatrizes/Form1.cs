﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteMatrizes
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;
            
            for (int i = 0; i < vetor.Length; i++)
            {


                aux = Interaction.InputBox($"\n\n Digite o {i + 1}° Número :", "Entrada de Dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Insira um valor válido (Números Inteiros");
                    i--;
                }
            }
            
            Array.Reverse(vetor);

            aux = "";

            foreach (int x in vetor) 
            { 
                aux += "\t" + x + "\n"; 
            }

            MessageBox.Show(aux);
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            string alunos_restantes = "";

            ArrayList alunos = new ArrayList()
            {
                "Ana", "André", "Débora", "Fátima",
                "João", "Janete", "Otávio", "Marcelo"
            };

            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            for (int i = 0; i < alunos.Count; i++)
            {
                alunos_restantes += alunos[i];
                if (i < alunos.Count - 1)
                {
                    alunos_restantes += ", ";
                }
            }
            MessageBox.Show(alunos_restantes);
        }

        private void BtnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] sum_notas = new double[20];
            string aux = "";
            
            for (int aluno = 0; aluno < 20; aluno++)
            {
                sum_notas[aluno] = 0;
                for (int nota = 0; nota < 3; nota++)
                {
                        if ((!double.TryParse(Interaction.InputBox($"Aluno{aluno + 1} \n " +
                            $"\nInsira a {nota + 1}° Nota", "Entrada de Notas"), out notas[aluno, nota])) 
                            || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                        {
                            MessageBox.Show("Insira um valor válido");
                            nota--;
                        }
                        else
                        {
                            sum_notas[aluno] += notas[aluno, nota];
                        }
                }
            }
            
            for (int cont = 0; cont < 20; cont++)
            {
                aux += $"Aluno {cont + 1:D2} : Média: " + ( sum_notas[cont] / 3.0 ).ToString("N1") + "\n";
            }
            MessageBox.Show(aux);
        }

        private void BtnExercicio4_Click(object sender, EventArgs e)
        {            
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"]?.BringToFront();
            }            
            else
            {
                FrmExercicio4 obj1 = new FrmExercicio4();
                obj1.Show();
            }
        }

        private void BtnExercicio5_Click(object sender, EventArgs e)
        {            
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"]?.BringToFront();
            }
            else
            {
                FrmExercicio5 obj1 = new FrmExercicio5();
                obj1.Show();
            }
        }
    }
}
