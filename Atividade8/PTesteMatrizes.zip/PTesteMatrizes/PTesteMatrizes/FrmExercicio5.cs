﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PTesteMatrizes
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }        

        private void btnValidar_Click(object sender, EventArgs e)
        {
            listBox.Items.Clear();

            string N;
            int RA;

            do
            {
                N = Interaction.InputBox("Insira o seu RA: ", "Entrada de dados");

                if (!int.TryParse(N[N.Length - 1].ToString(), out RA))
                {
                    MessageBox.Show("Insira um valor válido para RA");
                    N = "";
                }
                else
                {
                    if (RA == 0)
                    {
                        RA = 2;
                    }
                    else { RA += 1; }
                }
            } while (N == "");

            string notas="";
            string[] gabarito = new string[] { "E", "B", "A", "C", "A", "D", "E", "B", "D", "C" };
            string[,] respostas = new string[RA, 10];

            for (int aluno = 0; aluno < RA; aluno++)
            {
                for (int exercicio = 0; exercicio < 10; exercicio++)
                {
                    respostas[aluno, exercicio] = Interaction.InputBox($"Insira a {exercicio + 1}° resposta do {aluno + 1}° aluno", "Entrada das Respostas").ToUpper();

                    if (!(respostas[aluno, exercicio] == "A" || respostas[aluno, exercicio] == "B" || respostas[aluno, exercicio] == "C" || respostas[aluno, exercicio] == "D" || respostas[aluno, exercicio] == "E"))
                    {
                        MessageBox.Show("Insira uma Resposta valida \n (Respostas permitidas: A, B, C, D, E)");
                        exercicio--;
                    }
                }
            }            

            for (int aluno = 0; aluno < RA; aluno++)
            {
                notas = $"O Aluno {aluno + 1}: \n";
                listBox.Items.Add(notas);
                notas = "";
                for (int exercicio = 0; exercicio < 10; exercicio++)
                {                    
                    if (respostas[aluno, exercicio] == gabarito[exercicio])
                    {
                        notas += $"Ex. {exercicio + 1}: Resposta: {respostas[aluno, exercicio]} Gabarito: {gabarito[exercicio]}, Acertou \n ";
                    }
                    else
                    {
                        notas += $"Ex. {exercicio + 1}: Resposta: {respostas[aluno, exercicio]} Gabarito: {gabarito[exercicio]}, Errou \n";
                    }
                    listBox.Items.Add(notas);
                    notas = "";
                }
            }
            
        }
    }
}
