﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.textB = new System.Windows.Forms.TextBox();
            this.textC = new System.Windows.Forms.TextBox();
            this.btnExe = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(95, 67);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(83, 20);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Valor de A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(95, 145);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(83, 20);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "Valor de B";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(95, 226);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(83, 20);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "Valor de C";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(241, 64);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 26);
            this.txtA.TabIndex = 3;
            this.txtA.Validated += new System.EventHandler(this.textBox1_Validated);
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(241, 142);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(100, 26);
            this.textB.TabIndex = 4;
            this.textB.Validating += new System.ComponentModel.CancelEventHandler(this.textB_Validating);
            // 
            // textC
            // 
            this.textC.Location = new System.Drawing.Point(241, 223);
            this.textC.Name = "textC";
            this.textC.Size = new System.Drawing.Size(100, 26);
            this.textC.TabIndex = 5;
            this.textC.Validating += new System.ComponentModel.CancelEventHandler(this.textC_Validating);
            // 
            // btnExe
            // 
            this.btnExe.Location = new System.Drawing.Point(103, 321);
            this.btnExe.Name = "btnExe";
            this.btnExe.Size = new System.Drawing.Size(100, 36);
            this.btnExe.TabIndex = 6;
            this.btnExe.Text = "Executar";
            this.btnExe.UseVisualStyleBackColor = true;
            this.btnExe.Click += new System.EventHandler(this.btnExe_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(250, 321);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(100, 36);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExe);
            this.Controls.Add(this.textC);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "Ptriangulo";
            this.Load += new System.EventHandler(this.btnSair_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.TextBox textC;
        private System.Windows.Forms.Button btnExe;
        private System.Windows.Forms.Button btnSair;
    }
}

