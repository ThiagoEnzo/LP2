﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    

    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textC.Text, out ladoC))
            {
                MessageBox.Show("Nao eh um numero");
                return;
            }
            if (ladoC <= 0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
                return; 
            }
            if (!Double.TryParse(textB.Text, out ladoB))
            {
                MessageBox.Show("Nao eh um numero");
                return;
            }
            if (ladoB <= 0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
                return;
            }
            if (!Double.TryParse(txtA.Text, out ladoA))
            {
                MessageBox.Show("Nao eh um numero");
                return;
            }
            if (ladoA <= 0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
                return;
            }

            if (ladoA < ladoB + ladoC && ladoB < ladoA + ladoC && ladoC < ladoA + ladoB && ladoA > Math.Abs(ladoB - ladoC) && ladoB > Math.Abs(ladoA - ladoC) && ladoC > Math.Abs(ladoA - ladoB))
            {
                if (ladoA != ladoB && ladoA != ladoC && ladoC != ladoB)
                {
                    MessageBox.Show($"Triangulo Escaleno de lados {ladoA}, {ladoB}, {ladoC} ");
                }
                else if (ladoA == ladoB && ladoA == ladoC && ladoB == ladoC)
                {
                    MessageBox.Show($"Triangulo Equilatero de lados {ladoA}, {ladoB}, {ladoC} ");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    MessageBox.Show($"Triangulo Isosceles de lados {ladoA}, {ladoB}, {ladoC} ");                   
                   
                }
             
            }
            else
            {
                MessageBox.Show("Esses Valores nao formam Triangulo");
            }
        }

        private void textB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(textB.Text, out ladoB))
            {
                MessageBox.Show("Nao eh um numero");
            }
            if (ladoB <=0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
            }
        }

        private void textC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(textC.Text, out ladoC))
            {
                MessageBox.Show("Nao eh um numero");
            }
            if (ladoC <= 0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out ladoA))
            {
                MessageBox.Show("Nao eh um numero");
            }
            if(ladoA<=0)
            {
                MessageBox.Show("Numero menor ou igual a zero");
            }

           
        }
    }
}
